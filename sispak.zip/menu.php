	<div id="menu">
		<ul>
		   <li><a href="index.php">Home</a></li>
		   <li><a href="?page=konsul">Konsultasi</a></li>
		   <li><a href="?page=vkamus">Kamus Otomotif</a></li>
		</ul>
		</div>
